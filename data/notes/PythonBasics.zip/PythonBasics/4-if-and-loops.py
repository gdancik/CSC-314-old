######################################################################
# If statements are similar to Java/C++ but
# - there are no braces, the Python interpreter uses indentation to
#       identify blocks
# - there is a colon (:) after each condition
# - you use 'elif' instead of 'elseif'
######################################################################

# Note: the elif and else statements are optional
# what happens if the final print statement is indented?
num = 1
if num > 3 :
    print("number is > 3")
elif num < 3 :
    print ("number is < 3")
else :
    print ("number is 3")
print ("Not indented, so at end of if..elif..else statement")

print()

# use the words 'and' or 'or' to create joint conditions; 
if num >= 1 and num <= 10 :
    print("num is bewteen 1 and 10")
else :
    print("num is NOT between 1 and 10")

# more logical operators
print("1 == 1:", 1 == 1)
print("2 != 3: ", 2 != 3)
print("'is' in 'this': ", 'is' in 'this')
print("'is' not in 'this': ", 'is' not in 'this')

print()


######################################################################
# # In python, 'for loops' are used to iterate through each item of
# a sequence or a collection of items
######################################################################

# for loop example, iterating over each element of a string
str = "Hello"
for ch in str:
    print(ch)

print()
print()

# Tuples are a collection of items, like an array or list. 
# Tuples are immutable (the items cannot be changed directly). 
# Rules for concatenation and slicing apply.

words = ("hi", "bye", "why")
print(words)
print("number of words = ", len(words))
print()

# for loop example, iterating over each element of a tuple
nums = (5,8,11)
for i in nums :
    print (i)


# lists are like tuples but their elements are not immutable
# lists are created by surrounding a comma-separated list of
# objects in square brackets
l = [1,2,3]
l.append(20) # add an element to the end of a list
l[0] = 0 # change element at index 0

# for loop example, using range to create a list of integers
# range(start,stop,step = 1) generates a sequence of numbers where:
#   start = the first number
#   stop = the sequence stops BEFORE reaching this number
#   step = difference between each number (optional)

# loop through numbers 3-5
for i in range(3,6) :
    print(i)

print()


############################################################
# Exercise: use a for loop to add the numbers between 1-10
# and output the result
############################################################
