########################################################################
# Strings and tuples are immutable (their elements cannot be changed)
########################################################################

word = "hello"
print(word)
print()
#word[0] = 'H' # produces an error
 

#######################################################
# (Some) methods for changing a character of a string
#######################################################
 
#1. Using the replace function
#   Note that the replace function creates a new string with the specified 
#   substring replaced, and returns the new string. Therefore, word.replace() 
#   on its own does not change the value of the string 'word'. However, 
#   we can assign the new string to a variable. This replaces all 
#   occurences of the substring by default

print("Change word using replace: ")
print("word = " + word)
print("call word = word.replace('h', 'H')")
word = word.replace('h', 'H')
print("word = " + word)
print()
 

# 2. Convert the string to a list object and then convert it back to a string
#    using the 'join' method; the 'join' method is illustrated below


# The join method is a string method that concatenates elements of a list 
# or tuple, separated by the specified character or string. Note: 
# the elements of the list or tuple must be characters or strings.

l = ["hi", "fly", "bye"]
print("'-'.join(l) = " + '-'.join(l))   # outputs hi-fly-bye
print()
 
# We can therefore modify a character of a string as follows:
print("modify a string by converting to a list, modifying, and converting back to a string")
word = "hello"   # initial string
print ("word = " + word)
l = list(word)   # convert to list
l[0] = "H"	# change first character
word = ''.join(l)  # convert back to string (no spaces between each character)
print ("word = " + word)
 
