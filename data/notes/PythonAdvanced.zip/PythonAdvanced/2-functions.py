#########################################################################
# Functions in python
#   A function is a named set of statements that can be called 
#   A function should serve a specific purpose
#   A function can take values as inputs
#   As with if statements and loops, use indentation rather than braces
#   to create a block of code for a function
#   Use a 'return' statement to optionally return a value
#########################################################################

# use 'def' to define a function; all statements in the function are 
# indented
def welcome() :
  print ("This script demonstrates how to write functions in Python")
  print()

def add(x,y) :
  return x + y


welcome()  # display welcome message

# function returns the value 7, which is assigned to sum
sum = add(3,4)

print("add(3,4) = ", sum)

# statement below does the same as above
print("add(3,4) = ", add(3,4))


