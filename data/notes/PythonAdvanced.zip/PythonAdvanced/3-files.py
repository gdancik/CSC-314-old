#########################################################################
# File Input, For more, see section 7.2 from:
#	https://docs.python.org/3.6/tutorial/inputoutput.html
#########################################################################

# set end = '' to keep output on a single line
print('a', end = '')   
print('b', end = '')
print()
print()

########################################################################
# There are 3 ways to read the contents of a file
# for line in infile - iterate through the file one line at a time 
# infile.read() - read all contents as a single string
# infile.readline() - read the next line of the file, as a string
# infile.readlines() - read all contents and return a list, with
#                      each line of the file an element of the list

########################################################################

# store the file name in a string (you will need to specify the full path)
file = "3-files.py"

# using 'with' is the preferred way to open a file, as it automatically 
# closes the file when the block is exited; an error is raised
# if the file cannot be opened

# example using for loop
with open(file) as infile :
    # a 'for' loop can be used to iterate through each line of a file
    print ("The contents of the file is: ")
    for line in infile :
        print (line, end = '')
         
    
# example using readlines()
with open(file) as infile :
    lines = infile.readlines()

# each line of the file is an element of the list
print("second line is: ", lines[1])
print()
print("number of lines:", len(lines))


# Note: a useful string method is strip, which removes whitespace 
# characters (spaces, new lines, or tabs) from the beginning or 
# end of a string. Note that 'strip' does not change the string 
# itself, but returns a copy with leading/trailing whitespace 
# characters removed

x = "this is a line\n"
x.strip()
